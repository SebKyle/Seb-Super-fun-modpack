JEIEvents.hideItems(event => {
    event.hide('twilightforest:uncrafting_table')
})